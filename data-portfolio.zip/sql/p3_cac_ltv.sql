-- stg_spend: normalize channel names via seed table
SELECT s.day, COALESCE(m.channel, 'unmapped') AS channel, s.cost
FROM raw.ad_spend s LEFT JOIN seed_channel_map m ON lower(s.source_label) = m.raw_label;

-- stg_conversions: dedupe signups seen in two systems
SELECT DISTINCT ON (user_id) user_id, campaign_id, converted_at
FROM raw.conversions ORDER BY user_id, converted_at;

-- fct_channel_economics (quarterly)
SELECT c.channel,
  sum(sp.cost) AS spend, count(DISTINCT cv.user_id) AS customers,
  sum(sp.cost) / NULLIF(count(DISTINCT cv.user_id),0) AS cac,
  avg(sub.mrr) * 0.80 / NULLIF(avg(ch.monthly_churn),0) AS ltv,  -- 80% gross margin assumption
  sum(sp.cost) / NULLIF(count(DISTINCT cv.user_id),0) / NULLIF(avg(sub.mrr) * 0.80,0) AS payback_months
FROM stg_spend sp
JOIN stg_conversions cv USING (channel)
JOIN stg_subscriptions sub USING (user_id)
JOIN channel_churn ch USING (channel)
GROUP BY 1;

-- quality probes (0 rows expected, or warn thresholds)
SELECT count(*) FILTER (WHERE campaign_id IS NULL)::float / count(*) AS unattributed_share FROM stg_conversions;
SELECT channel FROM stg_spend WHERE channel = 'unmapped' GROUP BY 1;
SELECT user_id FROM stg_conversions GROUP BY 1 HAVING count(*) > 1;
