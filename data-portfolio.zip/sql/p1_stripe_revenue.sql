-- Raw log: idempotent webhook insert (duplicate deliveries are no-ops)
CREATE TABLE raw.stripe_events (
  event_id text PRIMARY KEY, type text NOT NULL, payload jsonb NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(), processed_at timestamptz);
-- handler: INSERT ... ON CONFLICT (event_id) DO NOTHING RETURNING event_id;
-- if no row returned -> duplicate, ack 200 and stop. Failed processing leaves processed_at NULL for retry.

-- stg_stripe_invoices: latest state per invoice, deduped
SELECT DISTINCT ON (payload->'data'->'object'->>'id')
  payload->'data'->'object'->>'id' AS invoice_id,
  payload->'data'->'object'->>'subscription' AS subscription_id,
  (payload->'data'->'object'->>'amount_paid')::bigint / 100.0 AS amount_paid,
  to_timestamp((payload->>'created')::bigint) AS event_ts
FROM raw.stripe_events WHERE type LIKE 'invoice.%'
ORDER BY 1, event_ts DESC;

-- fct_mrr: normalize to monthly; excludes one-time items and refunds
SELECT date_trunc('month', m.month_end) AS month, SUM(
  CASE s.interval WHEN 'year' THEN s.amount / 12.0 ELSE s.amount END) AS mrr
FROM dim_month m JOIN stg_subscriptions s
  ON s.started_at <= m.month_end AND (s.ended_at IS NULL OR s.ended_at > m.month_end)
WHERE s.status IN ('active','past_due') GROUP BY 1;

-- rec_daily: Stripe vs internal records
SELECT COALESCE(a.day,b.day) AS day, a.stripe_total, b.internal_total,
       COALESCE(b.internal_total,0) - COALESCE(a.stripe_total,0) AS diff
FROM stripe_daily a FULL JOIN internal_daily b USING (day)
WHERE abs(COALESCE(b.internal_total,0) - COALESCE(a.stripe_total,0)) > 1;
