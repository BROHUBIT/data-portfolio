-- fct_customer_events: lifecycle from monthly MRR snapshots
SELECT customer_id, month,
  CASE WHEN prev_mrr IS NULL AND mrr > 0 THEN 'new'
       WHEN prev_mrr > 0 AND mrr = 0 THEN 'churn'
       WHEN mrr > prev_mrr THEN 'expansion'
       WHEN mrr < prev_mrr AND mrr > 0 THEN 'contraction' ELSE 'flat' END AS event,
  mrr - COALESCE(prev_mrr,0) AS mrr_delta
FROM (SELECT customer_id, month, mrr,
        LAG(mrr) OVER (PARTITION BY customer_id ORDER BY month) AS prev_mrr
      FROM customer_mrr_monthly) t;

-- cohort retention: cohort = first PAID month
WITH c AS (SELECT customer_id, min(month) AS cohort FROM customer_mrr_monthly WHERE mrr > 0 GROUP BY 1)
SELECT c.cohort, (extract(year from age(m.month, c.cohort))*12 + extract(month from age(m.month, c.cohort)))::int AS month_n,
  count(DISTINCT m.customer_id) FILTER (WHERE m.mrr > 0)::numeric / count(DISTINCT c.customer_id) AS retained
FROM c JOIN customer_mrr_monthly m USING (customer_id) GROUP BY 1,2;

-- NRR
SELECT month, (start_mrr + expansion - contraction - churn) / start_mrr AS nrr FROM mrr_movements;

-- data-quality probes (each should return 0 rows)
SELECT customer_id FROM dim_customer GROUP BY 1 HAVING count(*) > 1;
SELECT customer_id FROM dim_customer WHERE status = 'canceled' AND cancelled_at IS NULL;
SELECT customer_id FROM dim_customer WHERE cohort_month <> date_trunc('month', first_paid_at);
