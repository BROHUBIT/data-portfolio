# Data Engineering & Analytics Portfolio

Synthetic, interactive case studies (Stripe revenue reliability, retention, CAC/LTV). No environment variables, APIs or database are required. Nothing here processes real payments or uses real client data.

## Run locally
    npm install
    npm run dev      # http://localhost:3000
    npm run build && npm start

## Publish to GitHub
    git init && git add . && git commit -m "Initial portfolio"
    git branch -M main
    git remote add origin https://github.com/<you>/<repo>.git
    git push -u origin main

## Deploy to Vercel
1. vercel.com → Add New → Project → import the GitHub repo.
2. Framework preset: Next.js (auto-detected). No env vars. Click Deploy.

## Files
- `lib/data.ts` deterministic synthetic data; `lib/meta.ts` case-study text, definitions, tests
- `components/Dash.tsx` dashboards; `sql/*.sql` representative SQL shown on the site
- Not included: dbt project folder, Stripe webhook code, ER diagram image (see SQL files for the designs)

## Personalize before sending
- [ ] Name in header (`app/page.tsx`), About text, email and LinkedIn
- [ ] Edit the Stack list to tools you have really used
- [ ] Add real, verifiable achievements only; keep the synthetic labels
- [ ] Set a real site title/description in `app/layout.tsx`
