'use client'
import { useMemo, useState } from 'react'
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts'
import { ROWS, MONTHS, PLANS, COHORTS, CUSTS, CHANNELS, RECON, FAILS, GM, type Plan, type Row, type Cust } from '@/lib/data'
import { META, type Meta } from '@/lib/meta'

const $ = (n: number) => '$' + Math.round(n).toLocaleString('en-US')
const pc = (n: number) => (n * 100).toFixed(1) + '%'
const TT = { contentStyle: { background: '#0a1020', border: '1px solid #334155' }, labelStyle: { color: '#e2e8f0' } }
type PF = Plan | 'All'

function series(plan: PF) {
  return MONTHS.map(m => {
    const rs = ROWS.filter(r => r.month === m && (plan === 'All' || r.plan === plan))
    const s = (k: keyof Row) => rs.reduce((a, r) => a + (r[k] as number), 0)
    return { month: m, subs: s('subs'), mrr: s('mrr'), gross: s('gross'), refunds: s('refunds'), failed: s('failed'), recovered: s('recovered'), churned: s('churned'), expansion: s('expansion'), contraction: s('contraction'), lost: s('lost') }
  })
}
function Kpi({ l, v, n }: { l: string; v: string; n?: string }) {
  return <div className="rounded-lg border border-white/10 bg-white/5 p-4"><dt className="text-xs text-slate-400">{l}</dt><dd className="mt-1 text-xl font-semibold text-white">{v}</dd>{n && <p className="text-xs text-slate-500">{n}</p>}</div>
}
function Box({ t, children }: { t: string; children: React.ReactNode }) {
  return <section className="min-w-0 rounded-lg border border-white/10 bg-white/5 p-4"><h4 className="mb-3 text-sm font-semibold text-emerald-300">{t}</h4>{children}</section>
}
const Empty = ({ m }: { m: string }) => <p role="status" className="rounded border border-dashed border-white/20 p-6 text-center text-sm text-slate-400">{m}</p>
function Chart({ label, children }: { label: string; children: React.ReactElement }) {
  return <div className="h-64 w-full" role="img" aria-label={label}><ResponsiveContainer width="100%" height="100%">{children}</ResponsiveContainer></div>
}
function PlanSel({ v, set }: { v: PF; set: (p: PF) => void }) {
  return <label className="text-sm">Plan{' '}<select className="ml-1 rounded border border-white/20 bg-[#0a1020] px-2 py-1" value={v} onChange={e => set(e.target.value as PF)}>{['All', ...PLANS].map(p => <option key={p}>{p}</option>)}</select></label>
}
const Th = ({ c }: { c: string[] }) => <thead><tr className="text-left text-xs text-slate-400">{c.map(x => <th key={x} scope="col" className="px-2 py-1 font-medium">{x}</th>)}</tr></thead>
const Td = ({ children }: { children: React.ReactNode }) => <td className="px-2 py-1.5">{children}</td>

function P1() {
  const [plan, setPlan] = useState<PF>('All')
  const d = useMemo(() => series(plan).map(x => ({ ...x, net: x.gross - x.refunds })), [plan])
  const l = d[d.length - 1]
  const custs = CUSTS.filter(c => (plan === 'All' || c.plan === plan) && c.failedPay > 0)
  return <div className="space-y-4">
    <PlanSel v={plan} set={setPlan} />
    <dl className="grid grid-cols-2 gap-3 md:grid-cols-4">
      <Kpi l="MRR" v={$(l.mrr)} n="Active subs, month end" /><Kpi l="ARR run rate" v={$(l.mrr * 12)} n="MRR × 12" />
      <Kpi l="Gross revenue (cash)" v={$(l.gross)} /><Kpi l="Refunds" v={$(l.refunds)} />
      <Kpi l="Failed payment rate" v={pc(l.failed / l.subs)} /><Kpi l="Recovery rate" v={pc(l.recovered / l.failed)} />
      <Kpi l="Net revenue (cash)" v={$(l.net)} n="Gross − refunds" /><Kpi l="Cash vs MRR gap" v={$(l.net - l.mrr)} n="Not interchangeable" />
    </dl>
    <div className="grid gap-4 lg:grid-cols-2">
      <Box t="MRR vs net cash collected (simulated)"><Chart label="Line chart of MRR and net cash by month"><LineChart data={d}><CartesianGrid stroke="#1e293b" /><XAxis dataKey="month" stroke="#94a3b8" /><YAxis stroke="#94a3b8" tickFormatter={v => '$' + v / 1000 + 'k'} /><Tooltip {...TT} formatter={(v: number) => $(v)} /><Legend /><Line dataKey="mrr" name="MRR" stroke="#34d399" dot={false} /><Line dataKey="net" name="Net cash" stroke="#60a5fa" dot={false} /></LineChart></Chart></Box>
      <Box t="Failed payments by reason (synthetic share)"><Chart label="Bar chart of failure reasons"><BarChart data={FAILS} layout="vertical" margin={{ left: 40 }}><CartesianGrid stroke="#1e293b" /><XAxis type="number" stroke="#94a3b8" /><YAxis type="category" dataKey="reason" stroke="#94a3b8" width={140} /><Tooltip {...TT} /><Bar dataKey="n" name="% of failures" fill="#f59e0b" /></BarChart></Chart></Box>
    </div>
    <Box t="Reconciliation: simulated Stripe events vs internal subscription records"><div className="overflow-x-auto"><table className="w-full text-sm"><caption className="sr-only">Reconciliation</caption><Th c={['Event', 'Type', 'Stripe', 'Internal', 'Diff', 'Status']} /><tbody>{RECON.map(e => <tr key={e.id} className="border-t border-white/10"><Td>{e.id}</Td><Td>{e.type}</Td><Td>{$(e.stripe)}</Td><Td>{$(e.internal)}</Td><Td>{$(e.internal - e.stripe)}</Td><Td><span className={e.status === 'Matched' ? 'text-emerald-300' : 'text-amber-300'}>{e.status}</span></Td></tr>)}</tbody></table></div>
      <p className="mt-2 text-xs text-slate-400">Duplicate events are blocked by the unique event_id key; the others route to a reconciliation queue for review.</p></Box>
    <Box t="Customer drill-down: accounts with failed payments">{custs.length === 0 ? <Empty m="No customers with failed payments for this plan. Choose another plan." /> :
      <div className="overflow-x-auto"><table className="w-full text-sm"><Th c={['Customer', 'Plan', 'MRR', 'Failed payments', 'Tenure (mo)']} /><tbody>{custs.map(c => <tr key={c.id} className="border-t border-white/10"><Td>{c.id}</Td><Td>{c.plan}</Td><Td>{$(c.mrr)}</Td><Td>{c.failedPay}</Td><Td>{c.tenure}</Td></tr>)}</tbody></table></div>}</Box>
  </div>
}

function score(c: Cust, th: number) {
  const w: [boolean, number, string][] = [[c.logins < th, 30, `logins ${c.logins} < ${th}`], [c.seats < 40, 20, 'seat use < 40%'], [c.tickets >= 3, 15, '3+ tickets'], [c.failedPay >= 2, 20, '2+ failed payments'], [c.tenure < 4, 15, 'tenure < 4 mo']]
  const h = w.filter(x => x[0])
  return { pts: h.reduce((a, x) => a + x[1], 0), why: h.map(x => x[2]).join(', ') || 'none' }
}
function P2() {
  const [plan, setPlan] = useState<PF>('All')
  const [th, setTh] = useState(8)
  const d = useMemo(() => series(plan).map(x => ({ ...x, logo: +(x.lost / x.subs * 100).toFixed(2), nrr: +(100 + (x.expansion - x.contraction - x.churned) / x.mrr * 100).toFixed(2) })), [plan])
  const l = d[d.length - 1]
  const list = useMemo(() => CUSTS.filter(c => plan === 'All' || c.plan === plan).map(c => ({ c, ...score(c, th) })).sort((a, b) => b.pts - a.pts), [plan, th])
  return <div className="space-y-4">
    <div className="flex flex-wrap gap-4"><PlanSel v={plan} set={setPlan} /></div>
    <dl className="grid grid-cols-2 gap-3 md:grid-cols-5"><Kpi l="Logo churn" v={l.logo + '%'} /><Kpi l="Revenue churn" v={pc(l.churned / l.mrr)} /><Kpi l="Expansion MRR" v={$(l.expansion)} /><Kpi l="Contraction MRR" v={$(l.contraction)} /><Kpi l="NRR (approx.)" v={l.nrr + '%'} /></dl>
    <div className="grid gap-4 lg:grid-cols-2">
      <Box t="Monthly logo churn % and NRR % (simulated)"><Chart label="Line chart of logo churn and NRR"><LineChart data={d}><CartesianGrid stroke="#1e293b" /><XAxis dataKey="month" stroke="#94a3b8" /><YAxis yAxisId="a" stroke="#94a3b8" /><YAxis yAxisId="b" orientation="right" stroke="#94a3b8" domain={[90, 110]} /><Tooltip {...TT} /><Legend /><Line yAxisId="a" dataKey="logo" name="Logo churn %" stroke="#f87171" dot={false} /><Line yAxisId="b" dataKey="nrr" name="NRR %" stroke="#34d399" dot={false} /></LineChart></Chart></Box>
      <Box t="Cohort retention (% of cohort still active)"><div className="overflow-x-auto"><table className="w-full text-center text-xs"><caption className="sr-only">Cohort retention</caption><Th c={['Cohort', 'Size', 'M0', 'M1', 'M2', 'M3', 'M4', 'M5']} /><tbody>{COHORTS.map(c => <tr key={c.cohort}><td className="px-2 py-1 text-left">{c.cohort}</td><td>{c.size}</td>{Array.from({ length: 6 }, (_, i) => c.ret[i] === undefined ? <td key={i} className="text-slate-600">–</td> : <td key={i} className="text-white" style={{ background: `rgba(52,211,153,${c.ret[i] / 160})` }}>{c.ret[i]}%</td>)}</tr>)}</tbody></table></div></Box>
    </div>
    <Box t="Churn-risk explorer (illustrative rules, not a validated model)">
      <label className="mb-3 block text-sm">Low-activity threshold: fewer than <b>{th}</b> logins / 30 days <input type="range" min={2} max={20} value={th} onChange={e => setTh(+e.target.value)} className="ml-2 align-middle accent-emerald-400" aria-label="Login threshold" /></label>
      {list.length === 0 ? <Empty m="No customers match this plan." /> : <div className="max-h-80 overflow-auto"><table className="w-full text-sm"><Th c={['Customer', 'Plan', 'Points', 'Band', 'Why']} /><tbody>{list.slice(0, 12).map(x => <tr key={x.c.id} className="border-t border-white/10"><Td>{x.c.id}</Td><Td>{x.c.plan}</Td><Td>{x.pts}</Td><Td>{x.pts >= 50 ? 'High' : x.pts >= 25 ? 'Medium' : 'Low'}</Td><Td>{x.why}</Td></tr>)}</tbody></table></div>}
    </Box>
  </div>
}

function P3() {
  const [on, setOn] = useState<string[]>(CHANNELS.map(c => c.name))
  const rows = CHANNELS.filter(c => on.includes(c.name)).map(c => { const cac = c.spend / c.customers, ltv = c.arpa * GM / c.churn; return { ...c, cac, ltv, ratio: +(ltv / cac).toFixed(2), payback: +(cac / (c.arpa * GM)).toFixed(1), conv: c.customers / c.signups } })
  const sp = rows.reduce((a, r) => a + r.spend, 0), cu = rows.reduce((a, r) => a + r.customers, 0)
  const bl = rows.reduce((a, r) => a + r.ltv * r.customers, 0) / (cu || 1)
  return <div className="space-y-4">
    <fieldset className="flex flex-wrap gap-2"><legend className="mb-1 text-sm">Channels (quarter, synthetic)</legend>{CHANNELS.map(c => <label key={c.name} className="flex items-center gap-1 rounded border border-white/20 px-2 py-1 text-sm"><input type="checkbox" className="accent-emerald-400" checked={on.includes(c.name)} onChange={e => setOn(e.target.checked ? [...on, c.name] : on.filter(n => n !== c.name))} />{c.name}</label>)}</fieldset>
    {rows.length === 0 ? <Empty m="No channels selected. Tick at least one channel to see CAC and LTV." /> : <>
      <dl className="grid grid-cols-2 gap-3 md:grid-cols-4"><Kpi l="Spend" v={$(sp)} /><Kpi l="New customers" v={String(cu)} /><Kpi l="Blended CAC" v={$(sp / cu)} /><Kpi l="Blended LTV:CAC" v={(bl / (sp / cu)).toFixed(1) + 'x'} /></dl>
      <Box t="LTV:CAC by channel"><Chart label="Bar chart of LTV to CAC by channel"><BarChart data={rows}><CartesianGrid stroke="#1e293b" /><XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 11 }} /><YAxis stroke="#94a3b8" /><Tooltip {...TT} /><Bar dataKey="ratio" name="LTV:CAC" fill="#34d399" /></BarChart></Chart></Box>
      <Box t="Channel comparison"><div className="overflow-x-auto"><table className="w-full text-sm"><Th c={['Channel', 'Spend', 'Signups', 'Customers', 'Signup→paid', 'CAC', 'LTV', 'LTV:CAC', 'Payback (mo)']} /><tbody>{rows.map(r => <tr key={r.name} className="border-t border-white/10"><Td>{r.name}</Td><Td>{$(r.spend)}</Td><Td>{r.signups}</Td><Td>{r.customers}</Td><Td>{pc(r.conv)}</Td><Td>{$(r.cac)}</Td><Td>{$(r.ltv)}</Td><Td><span className={r.ratio < 3 ? 'text-amber-300' : 'text-emerald-300'}>{r.ratio}x</span></Td><Td>{r.payback}</Td></tr>)}</tbody></table></div></Box>
      <Box t="Attribution limits and assumptions"><ul className="list-disc space-y-1 pl-5 text-sm"><li>First-touch attribution; assisted and offline influence are not captured.</li><li>Assumes 80% gross margin and constant monthly churn per channel (LTV is sensitive to this).</li><li>Spend is treated as fully loaded; agency fees and salaries are not itemized.</li><li>Roughly 10% of real-world conversions typically lack campaign tags; here that is a warn-level test, not a modelled value.</li></ul></Box></>}
  </div>
}

export default function Dash({ sql }: { sql: Record<string, string> }) {
  const [id, setId] = useState('p1')
  const m: Meta = META.find(x => x.id === id) ?? META[0]
  return <div>
    <div role="tablist" aria-label="Case studies" className="grid gap-3 md:grid-cols-3">
      {META.map(x => <button key={x.id} role="tab" id={'tab-' + x.id} aria-selected={id === x.id} aria-controls="panel" onClick={() => setId(x.id)} className={'rounded-lg border p-4 text-left transition-colors ' + (id === x.id ? 'border-emerald-400 bg-emerald-400/10' : 'border-white/10 bg-white/5 hover:border-white/30')}>
        <span className="block font-semibold text-white">{x.title}</span><span className="mt-1 block text-xs text-slate-400">{x.tag}</span></button>)}
    </div>
    <div id="panel" role="tabpanel" aria-labelledby={'tab-' + id} className="mt-6 space-y-6">
      <p className="rounded border border-amber-400/30 bg-amber-400/10 p-3 text-sm text-amber-200">Synthetic case study. All data is generated, no real client or Stripe account is involved, and outcomes are hypothetical targets, not measured results.</p>
      <div><h3 className="text-xl font-semibold text-white">{m.title}</h3><p className="mt-1 max-w-3xl">{m.problem}</p></div>
      {id === 'p1' ? <P1 /> : id === 'p2' ? <P2 /> : <P3 />}
      <Box t="Architecture"><ol className="flex flex-wrap items-center gap-2 text-xs">{m.flow.map((f, i) => <li key={f} className="flex items-center gap-2"><span className="rounded border border-emerald-400/40 bg-emerald-400/5 px-2 py-1">{f}</span>{i < m.flow.length - 1 && <span aria-hidden>→</span>}</li>)}</ol></Box>
      <Box t="Bottleneck → root cause → solution → expected outcome (hypothetical)"><div className="overflow-x-auto"><table className="w-full text-sm"><Th c={['Bottleneck', 'Root cause', 'Optimized solution', 'Expected outcome']} /><tbody>{m.bn.map(b => <tr key={b[0]} className="border-t border-white/10 align-top">{b.map(c => <Td key={c}>{c}</Td>)}</tr>)}</tbody></table></div></Box>
      <div className="grid gap-4 lg:grid-cols-2">
        <Box t="Metric definitions"><dl className="space-y-2 text-sm">{m.defs.map(([k, v]) => <div key={k}><dt className="font-medium text-white">{k}</dt><dd className="text-slate-400">{v}</dd></div>)}</dl></Box>
        <Box t="Data-quality tests"><ul className="list-disc space-y-1 pl-5 text-sm">{m.tests.map(t => <li key={t}><code>{t}</code></li>)}</ul><p className="mt-3 text-sm"><b className="text-white">Trade-offs and limits:</b> {m.tradeoffs}</p></Box>
      </div>
      <Box t="Representative SQL (PostgreSQL / dbt style)"><pre className="max-h-96 overflow-auto rounded bg-black/40 p-3 text-xs" tabIndex={0}><code>{sql[id]}</code></pre></Box>
      <Box t="Why this matters commercially"><p className="text-sm">{m.ceo}</p></Box>
    </div>
  </div>
}
