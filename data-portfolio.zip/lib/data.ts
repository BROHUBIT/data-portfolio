// Fully synthetic, deterministic data (seeded LCG). No real customers, Stripe accounts or clients.
export const PLANS=['Starter','Growth','Scale'] as const
export type Plan=typeof PLANS[number]
function rng(s:number){return()=>(s=(s*1664525+1013904223)%4294967296)/4294967296}
const r=rng(42)
export const MONTHS=['Nov','Dec','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct']
export const PRICE:Record<Plan,number>={Starter:49,Growth:199,Scale:799}
export type Row={month:string;plan:Plan;subs:number;mrr:number;gross:number;refunds:number;failed:number;recovered:number;churned:number;expansion:number;contraction:number;lost:number}
export const ROWS:Row[]=[]
const subs:Record<Plan,number>={Starter:220,Growth:80,Scale:12}
MONTHS.forEach(month=>PLANS.forEach(plan=>{
  subs[plan]=Math.round(subs[plan]*(1.03+r()*0.04))
  const s=subs[plan],mrr=s*PRICE[plan],gross=Math.round(mrr*(1+r()*0.03)),failed=Math.round(s*(0.05+r()*0.04))
  ROWS.push({month,plan,subs:s,mrr,gross,refunds:Math.round(gross*(0.01+r()*0.015)),failed,recovered:Math.round(failed*(0.35+r()*0.2)),
    churned:Math.round(mrr*(0.015+r()*0.02)),expansion:Math.round(mrr*(0.01+r()*0.02)),contraction:Math.round(mrr*(0.003+r()*0.006)),lost:Math.round(s*(0.02+r()*0.025))})
}))
export const FAILS=[{reason:'Insufficient funds',n:41},{reason:'Card expired',n:27},{reason:'Do not honor',n:18},{reason:'Authentication required',n:9},{reason:'Other',n:5}]
export type Recon={id:string;type:string;stripe:number;internal:number;status:'Matched'|'Duplicate event'|'Missing internally'|'Amount mismatch'}
export const RECON:Recon[]=[
  {id:'evt_demo_001',type:'invoice.paid',stripe:199,internal:199,status:'Matched'},
  {id:'evt_demo_002',type:'invoice.paid',stripe:799,internal:799,status:'Matched'},
  {id:'evt_demo_003',type:'invoice.paid',stripe:199,internal:398,status:'Duplicate event'},
  {id:'evt_demo_004',type:'charge.refunded',stripe:-49,internal:0,status:'Missing internally'},
  {id:'evt_demo_005',type:'invoice.paid',stripe:49,internal:59,status:'Amount mismatch'},
  {id:'evt_demo_006',type:'invoice.paid',stripe:199,internal:199,status:'Matched'}]
export const COHORTS=['May','Jun','Jul','Aug','Sep','Oct'].map((c,i)=>({cohort:c,size:90+Math.round(r()*40),ret:Array.from({length:6-i},(_,m)=>Math.round(100*Math.exp(-m*(0.09+r()*0.05))))}))
export type Cust={id:string;plan:Plan;tenure:number;logins:number;seats:number;tickets:number;failedPay:number;mrr:number}
export const CUSTS:Cust[]=Array.from({length:40},(_,i)=>{const plan=PLANS[Math.floor(r()*3)];return{id:`cus_demo_${String(i+1).padStart(3,'0')}`,plan,tenure:1+Math.floor(r()*24),logins:Math.floor(r()*30),seats:Math.round(20+r()*80),tickets:Math.floor(r()*5),failedPay:Math.floor(r()*r()*4),mrr:PRICE[plan]}})
export const GM=0.8
export const CHANNELS=[
  {name:'Paid Search',spend:240000,signups:1900,customers:190,arpa:210,churn:0.03},
  {name:'Paid Social',spend:180000,signups:2100,customers:105,arpa:120,churn:0.055},
  {name:'Content / SEO',spend:160000,signups:1200,customers:160,arpa:180,churn:0.022},
  {name:'Email / Lifecycle',spend:45000,signups:500,customers:70,arpa:160,churn:0.025},
  {name:'Referral',spend:95000,signups:380,customers:95,arpa:220,churn:0.018},
  {name:'Outbound',spend:300000,signups:260,customers:40,arpa:480,churn:0.028}]
