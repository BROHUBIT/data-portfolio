import type { Metadata } from 'next'
import './globals.css'
export const metadata: Metadata = { title:'Data Engineering & Analytics Portfolio', description:'Synthetic, interactive case studies in revenue, retention and growth analytics.' }
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
