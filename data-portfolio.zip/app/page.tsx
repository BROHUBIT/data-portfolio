import fs from 'node:fs'
import path from 'node:path'
import Dash from '@/components/Dash'
import { Database, ShieldCheck, Workflow, BarChart3, Mail, Linkedin } from 'lucide-react'

const read = (f: string) => fs.readFileSync(path.join(process.cwd(), 'sql', f), 'utf8')
const caps = [
  { i: Workflow, t: 'Pipelines', d: 'Idempotent ingestion, retries, raw event logs, incremental models.' },
  { i: Database, t: 'Modeling', d: 'Staging, marts and one documented metric dictionary.' },
  { i: ShieldCheck, t: 'Data quality', d: 'dbt tests, reconciliation checks, freshness and anomaly alerts.' },
  { i: BarChart3, t: 'Analytics', d: 'Executive dashboards, cohort and unit-economics analysis.' }]
const nav = [['Case studies', '#case-studies'], ['Capabilities', '#capabilities'], ['Stack', '#stack'], ['About', '#about'], ['Contact', '#contact']]
export default function Page() {
  const sql = { p1: read('p1_stripe_revenue.sql'), p2: read('p2_retention.sql'), p3: read('p3_cac_ltv.sql') }
  return <>
    <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:p-2">Skip to content</a>
    <header className="sticky top-0 z-10 border-b border-white/10 bg-[#0a1020]/90 backdrop-blur"><nav aria-label="Primary" className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-3"><span className="font-semibold text-white">[Your Name]</span><ul className="flex flex-wrap gap-4 text-sm">{nav.map(([n, h]) => <li key={h}><a className="hover:text-emerald-300" href={h}>{n}</a></li>)}</ul></nav></header>
    <main id="main" className="mx-auto max-w-6xl space-y-20 px-4 py-12">
      <section className="max-w-3xl"><h1 className="text-4xl font-bold leading-tight text-white md:text-5xl">Reliable revenue, retention and growth numbers for post-funding startups.</h1>
        <p className="mt-4 text-lg">Data engineering, analytics engineering and BI: I build the pipelines and metric definitions that let a CEO trust the dashboard. Below are three interactive, synthetic case studies.</p>
        <a href="#contact" className="mt-6 inline-block rounded bg-emerald-400 px-5 py-2.5 font-semibold text-[#0a1020] hover:bg-emerald-300">Discuss your data challenges</a></section>
      <section id="case-studies" aria-labelledby="cs"><h2 id="cs" className="mb-6 text-2xl font-semibold text-white">Case studies</h2><Dash sql={sql} /></section>
      <section id="capabilities" aria-labelledby="cap"><h2 id="cap" className="mb-6 text-2xl font-semibold text-white">Architecture and engineering capabilities</h2>
        <ul className="grid gap-4 md:grid-cols-4">{caps.map(c => <li key={c.t} className="rounded-lg border border-white/10 bg-white/5 p-4"><c.i aria-hidden className="mb-2 text-emerald-300" /><h3 className="font-semibold text-white">{c.t}</h3><p className="text-sm text-slate-400">{c.d}</p></li>)}</ul></section>
      <section id="stack" aria-labelledby="st"><h2 id="st" className="mb-4 text-2xl font-semibold text-white">Technical stack</h2>
        <p className="text-sm">Demo: Next.js, TypeScript, Tailwind, Recharts. Data work shown: PostgreSQL SQL, dbt-style models and tests, Stripe webhook concepts. <span className="text-slate-400">Edit this list to match tools you have actually used.</span></p></section>
      <section id="about" aria-labelledby="ab"><h2 id="ab" className="mb-4 text-2xl font-semibold text-white">About</h2>
        <p className="max-w-2xl">[EDIT: your real background. 8+ years in data: roles, industries, tools, and one or two verifiable outcomes you can discuss. Remove anything you cannot back up.]</p></section>
      <section id="contact" aria-labelledby="ct" className="rounded-lg border border-emerald-400/30 bg-emerald-400/5 p-6"><h2 id="ct" className="text-2xl font-semibold text-white">Let&apos;s talk about your data challenges</h2>
        <p className="mt-2">Founders and data leaders: if your revenue, churn or CAC numbers are hard to trust, I&apos;d like to hear about it.</p>
        <p className="mt-4 flex flex-wrap gap-6"><a className="flex items-center gap-2 hover:text-emerald-300" href="mailto:you@example.com"><Mail size={18} aria-hidden />you@example.com</a><a className="flex items-center gap-2 hover:text-emerald-300" href="https://www.linkedin.com/in/your-handle"><Linkedin size={18} aria-hidden />linkedin.com/in/your-handle</a></p></section>
    </main>
    <footer className="border-t border-white/10 py-6 text-center text-xs text-slate-500">All data and results on this site are synthetic or hypothetical. Not affiliated with Stripe.</footer>
  </>
}
